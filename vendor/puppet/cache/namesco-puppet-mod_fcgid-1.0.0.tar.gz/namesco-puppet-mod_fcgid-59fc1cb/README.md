puppet-mod_fcgid
================

Installs the Apache mod_fcgid module for the built in Apache on OS X
