# TotalFinder Puppet Module for Boxen

This module installs the latest version of [TotalFinder](http://totalfinder.binaryage.com/)

A great module has a working CI build, right?

[![Build Status](https://travis-ci.org/boxen/puppet-totalfinder.svg?branch=master)](https://travis-ci.org/boxen/puppet-totalfinder)

## Usage

### Include the Class in Your Module (personal, site, etc.)

```puppet
include totalfinder
```

## Required Puppet Modules

* `boxen`

## Development

_**You Know The Drill**_

1. Fork It
2. Change It
3. Test It
4. Pull It

Run `script/cibuild` to test it. Check the `script` directory for other useful tools.
